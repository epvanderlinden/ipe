----------------------------------------------------------------------
-- Customized ipelet: customize.lua
----------------------------------------------------------------------
prefs.max_zoom = 100
shortcuts.ipelet_1_symbols = "Shift+S"
shortcuts.mode_splines = "Alt+Ctrl+I"
prefs.scroll.vertical_sign = -1
-- Substitute with /path/to/ElectricalEngineering.isy
prefs.styles = { "~/.ipe/styles/ElectricalEngineering.isy" }
